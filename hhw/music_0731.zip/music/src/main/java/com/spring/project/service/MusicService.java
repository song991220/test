package com.spring.project.service;

import java.util.List;

import com.spring.project.ComcodeVo;

public interface MusicService {
	List<ComcodeVo> getComcodeLists();
}
