package com.spring.project.controller;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AjaxController {

	@GetMapping("/ajax")
	public ModelAndView test() {
		return new ModelAndView("/ajax/01");
	}
	
	// ajax의 응답은 string responseBody형태가되어야 함
	@PostMapping("/ajax")
	@ResponseBody
	public String testPost(@RequestParam("temp") String t ) {
		System.out.println(t);
		return "success";
	}
	
}
