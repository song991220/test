package com.spring.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.ItemService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.PagingVo;

@Controller
public class ItemController {
	
	@Autowired
	ItemService itemService;
	
	// 곡 전체 리스트
	@RequestMapping(value = "/newItemList", method = RequestMethod.GET)
	public ModelAndView newItem(){
		return new ModelAndView("album/albumList");
	}
	
	@ResponseBody 
	@RequestMapping(value = "/newItemList")
	public List<ItemVo> newItemPost(){
		List<ItemVo> list = itemService.newItemList();
		System.out.println(list);
		return list;
	}
	
	
	
	@RequestMapping(value = "/genre")
	public ModelAndView newGenre(@RequestParam Map<String, Object> map){
		ModelAndView ma = new ModelAndView();
		
		List<ItemVo> list = itemService.newgenreList(map);

		ma.addObject("lists", list);
		ma.setViewName("/album/genreList");
		
//		int total = itemService.countItemList(cri);
//		PagingVo page = new PagingVo(cri, total);
//		
//		ma.addObject("pageMaker", page);
//		System.out.println(list);
//		
		return ma;
	}
	
		

}
