package com.spring.project.vo;

public class CriteriaVO {

	private int page, perPageNum;

	// 페이지의 게시글 시작 번호
	public int getPageStart() {
		return (this.page-1)*perPageNum;
	}
	
	// 
	public CriteriaVO() {
		this.page=1;
		this.perPageNum=10;
	}
	
	// 페이지 번호
	public int getPage(){
		return page;
	}
	
	// 페이지 번호 음수가 되지 않게 setting
	public void setPage(int page) {
		if(page<=0)
			this.page=1;
		else
			this.page=page;
	}
	
	// 페이지당 보여주는 게시글 갯수
	public int getPerPageNum() {
		return perPageNum;
	}
	
	// 페이지당 보여주는 게시글 갯수 setting(고정)
	public void setPerPageNum(int pageCount) {
		int cnt = this.perPageNum;
		if (pageCount != cnt)
			this.perPageNum = cnt;
		else
			this.perPageNum=pageCount;
				
	}
}
