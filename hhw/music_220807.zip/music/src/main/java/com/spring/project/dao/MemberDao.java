package com.spring.project.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.MemberVO;

@Repository
public class MemberDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	public String logincheck(MemberVO memberVO) {
		return sqlSessionTemplate.selectOne("memberLoginCheck", memberVO);
	}

	public void signUp(Map<String, Object> map) {
		sqlSessionTemplate.insert("signUp", map);

	}

}
