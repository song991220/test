package com.spring.project.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.MemberService;
import com.spring.project.vo.MemberVO;

@Controller
@RequestMapping(value = "/member/*")
public class MemberController {	
	
	@Autowired
	MemberService memberService;
	
	@GetMapping(value ="/login")
	 public String login() {
	  return "member/login";
	}

	
	@PostMapping(value = "/loginCheck")
	public ModelAndView login_check(@ModelAttribute MemberVO memberVO, HttpSession session) {
	 String name = memberService.loginCheck(memberVO, session);  
	 ModelAndView mv = new ModelAndView();
	  if (name != null) { // 로그인 성공 시
	   mv.setViewName("member/authTestPage"); // 뷰의 이름
	   ///////////////////////////////////////
	   System.out.println("로그인 성공!!!");
	   ///////////////////////////////////////
	   } else { // 로그인 실패 시
	     mv.setViewName("member/login"); 		
	     mv.addObject("message", "error");
	     ///////////////////////////////////////
	     System.out.println("로그인 실패!!!");
	     ///////////////////////////////////////
	     }
	     return mv;
	   }
	   
	@GetMapping(value = "/logout.do")
	public ModelAndView logout(HttpSession session, ModelAndView mav) {
	memberService.logout(session); 
	 mav.setViewName("member/logout"); 
	 mav.addObject("message", "logout"); 
	  return mav;
	  }
	
// 권한 에러 발생시	
	@RequestMapping("/noauth")
	public String auth() {
		return "member/noauth";
	}
	
	//회원가입
	@GetMapping("/signUp")
	public String signUp() {
		return "member/signup";
	}
	
	@PostMapping("/signUp")
	public ModelAndView signUpPost(@RequestParam Map<String, Object> map, String psw, String con_psw) {
		ModelAndView mv = new ModelAndView();
		
		if (!psw.equals(con_psw)) {
			mv.setViewName("member/signupFail");
			return mv;
		}
		
		memberService.signUp(map);
		mv.setViewName("member/signupAlert");
		
		return mv;
	}
	
	
	// 비밀번호 찾기
	@GetMapping("/findPw")
	public String findPw() {
		return "member/findPw";
	}

	
	
}
