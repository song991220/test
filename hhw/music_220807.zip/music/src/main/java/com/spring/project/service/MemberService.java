package com.spring.project.service;

import java.util.Map;

import javax.servlet.http.HttpSession;

import com.spring.project.vo.MemberVO;

public interface MemberService {
	
public String loginCheck(MemberVO memberVO, HttpSession session);

public void logout(HttpSession session);

public void signUp(Map<String, Object> map);

}
