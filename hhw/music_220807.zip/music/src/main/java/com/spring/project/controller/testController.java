package com.spring.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.testService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ItemVo;

@Controller
public class testController {

	@Autowired
	testService testservice;
	
	@RequestMapping(value = "/testAlbum", method = RequestMethod.GET)
	public ModelAndView testAlbum(){
		return new ModelAndView("album/albumList");
	}
	
	@ResponseBody 
	@RequestMapping(value = "/testAlbum")
	public List<AlbumVo> testAlbumPost(){
		List<AlbumVo> list = testservice.testList();
		System.out.println(list);
		return list;
	}
	
	@RequestMapping(value = "/testItem", method = RequestMethod.GET)
	public ModelAndView testItem(){
		return new ModelAndView("album/albumList");
	}
	
	@ResponseBody 
	@RequestMapping(value = "/testItem")
	public List<ItemVo> testItemPost(){
		List<ItemVo> list = testservice.testItemList();
		System.out.println(list);
		return list;
	}
}
