package com.spring.project.serviceimpl;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.MemberDao;
import com.spring.project.service.MemberService;
import com.spring.project.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao memberDao;
	
	// 로그인
	@Override
	public String loginCheck(MemberVO memberVO, HttpSession session) {
		String id = memberDao.logincheck(memberVO);
		if (id != null) { // 세션 변수 저장
			session.setAttribute("id", memberVO.getId());
			session.setAttribute("membership", id);
//			------------------------------------------------확인용
			System.out.println("getid : "+memberVO.getId());
			System.out.println("id : "+id);
			System.out.println("session membership : "+session.getAttribute("membership")); 
			// session 에 membership 이란 이름으로 멤버의 등급이 저장된 모습. 이걸로 각 번호별
			// 권한 값을 지정하면 될 것 같다.
			/////////////////////////////////////////////////////
		}
		return id;
	}
	
	// 로그아웃
	@Override
	public void logout (HttpSession session) {
		session.invalidate(); // 세션 초기화
	}
	
	// 회원가입
	@Override
	public void signUp(Map<String, Object> map) {
		memberDao.signUp(map);
	}

}
