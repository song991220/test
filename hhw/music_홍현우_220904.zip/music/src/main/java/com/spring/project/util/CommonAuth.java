package com.spring.project.util;

import javax.servlet.http.HttpSession;

public class CommonAuth {

	// session 을 매개변수로 하면 결국 다른곳에서 HttpSession 을 호출하는것과 다를바가 없지않나?
	public String commonAuth(String value, HttpSession session) {
		String membership = (String)session.getAttribute(value);
		return membership;
	}
	
}
