package com.spring.project.service;

import java.util.Map;

import javax.servlet.http.HttpSession;

import com.spring.project.vo.MemberVO;

public interface MemberService {

	public MemberVO memberInfo(String id, HttpSession session, MemberVO memberVO);

	public void logout(HttpSession session);

	public void signUp(Map<String, Object> map);

	public String regdateCheck(MemberVO memberVO);

	public void memberModify(MemberVO memberVO);

	// 아이디 중복체크
	public String idCheck(String id);
	
	// 별명 중복체크
	public String aliesCheck(String alies);
}
