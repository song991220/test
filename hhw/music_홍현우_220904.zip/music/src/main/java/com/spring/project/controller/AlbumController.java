package com.spring.project.controller;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.AlbumService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.PagingVo;

@Controller
public class AlbumController {

	@Autowired
	AlbumService albumservice;
	
	@Autowired
	ServletContext context;
	
	/* 앨범 전체 리스트(GET) */
	@RequestMapping(value = "/newAlbumList", method = RequestMethod.GET)
	public ModelAndView testAlbum(CriteriaVO cri){
		
		ModelAndView ma = new ModelAndView("album/newAlbumList");
		
		int total = albumservice.countAlbumList();
		PagingVo pageMaker = new PagingVo(cri, total);
		
		ma.addObject("pageMaker", pageMaker);
		
		return ma;
	}
	
	/* 앨범 전체 리스트(POST) */
	@ResponseBody 
	@RequestMapping(value = "/newAlbumList")
	public List<AlbumVo> testAlbumPost(CriteriaVO cri){
		List<AlbumVo> list = albumservice.selectAlbumList(cri);
		return list;
	}
	

	/* 앨범 생성(create) (GET) */
	@RequestMapping(value = "/albumCreate", method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("album/create");
	}
	
	/* 앨범 생성(create) (POST) */
	@RequestMapping(value =  "/albumCreate", method = RequestMethod.POST)
	public String albumCreate(AlbumVo vo, MultipartFile file) throws Exception {
		
		String imgPath = context.getRealPath("/") + "/resources/image/"+file.getOriginalFilename();
		System.out.println(imgPath);
		
		FileCopyUtils.copy(file.getBytes(), new File(imgPath));
		
		vo.setImg("/resources/image/"+file.getOriginalFilename());
		
		albumservice.create(vo);

		return "redirect:/newAlbumList";
	}

	
	/* 앨범 상세페이지 */
	@RequestMapping(value = "/albumDetail", method = RequestMethod.GET)
	public ModelAndView albumDetail(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/detail");
		return ma;
	}

	/* 앨범 수정페이지(GET) */
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.GET)
	public ModelAndView albumUpdateView(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);

		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/update");

		return ma;
	}
	
	/* 앨범 수정페이지(POST) */
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.POST)
	public ModelAndView albumUpdate(@RequestParam Map<String, Object> map) {
		boolean isSuccess = albumservice.update(map);
		ModelAndView ma = new ModelAndView();

		if (isSuccess)
			ma.setViewName("redirect:/newAlbumList");
		else
			ma = albumUpdateView(map);

		return ma;
	}

	
	/* 앨범 삭제(GET) */
	@RequestMapping(value = "/albumDelete", method = RequestMethod.GET)
	public ModelAndView albumDelete(@RequestParam Map<String, Object> map) {
		ModelAndView ma = new ModelAndView();
		AlbumVo vo = new AlbumVo();

		boolean isSuccess = albumservice.delete(map);

		if (isSuccess)
			ma.setViewName("redirect:/newAlbumList");
		else
			ma.setViewName("/albumDelete?albumID=" + vo.getId());

		return ma;
	}

	
	/* 실시간 음악 - 앨범(GET) */
	@GetMapping(value = "/bestAlbumList")
	public ModelAndView bestAlbumListGet() {
		ModelAndView ma = new ModelAndView("/album/bestAlbumList");
		return ma;
	}
	
	/* 실시간 음악 - 앨범(POST) */
	@ResponseBody
	@RequestMapping(value = "/bestAlbumList")
	public List<AlbumVo> bestAlbumListPost() {
		List<AlbumVo> list = albumservice.bestAlbumList();
		return list;
	}
	
	
}
