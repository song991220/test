package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.ItemDao;
import com.spring.project.service.ItemService;
import com.spring.project.vo.CartVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.orderListVo;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemDao itemDao;
	
	// 곡 전체 갯수
	@Override
	public int countItemList(CriteriaVO cri) {
		return itemDao.itemCount(cri);
	}
	
	// 곡 전체 리스트
	@Override
	public List<ItemVo> newItemList() {
		return itemDao.ItemList();
	}
	
	// 장르 리스트
	@Override
	public List<ItemVo> newgenreList(Map<String, Object> map) {
		return itemDao.newGenreList(map);
	}
	
	// 곡 조회수
	@Override
	public void viewCount(int itemID) {
		itemDao.addViewCount(itemID);
	}

	/* 곡 상세페이지 */
	@Override
	public Map<String, Object> detail(Map<String, Object> map) {
		return itemDao.itemDetail(map);
	}

	/* 실시간 음악 - 곡 */
	@Override
	public List<ItemVo> bestItemList() {
		return itemDao.bestItemList();
	}

	/* 아이템 Create */
	@Override
	public int itemCreate(Map<String, Object> map) {
		return itemDao.itemCreate(map);
	}
	
	/* 아이템에 대한 앨범 정보 */
	@Override
	public List<ItemVo> albumSelect(ItemVo itemVo) {
		return itemDao.albumSelect(itemVo);
	}

	/* 인기음악 */
	@Override
	public List<ItemVo> randomList() {
		return itemDao.randomList();
	}

	/* 장바구니 Insert */
	@Override
	public void cartInsert(CartVo vo) {
		itemDao.cartAdd(vo);
	}

	/* 마이 페이지 (장바구니 리스트) */
	@Override
	public List<CartVo> cartList(Map<String, Object> map) {
		return itemDao.cartList(map);
	}

	/* 장바구니 아이템 성공시 업데이트 */
	@Override
	public void delynUpdate(CartVo cartVO) {
		itemDao.delynUpdate(cartVO);
	}

	/* 주문내역 */
	@Override
	public List<orderListVo> orderList(orderListVo orderListvo) {
		return itemDao.orderList(orderListvo);
	}
	

}
