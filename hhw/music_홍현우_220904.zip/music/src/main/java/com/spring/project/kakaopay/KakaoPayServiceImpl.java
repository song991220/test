package com.spring.project.kakaopay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.vo.MemberVO;

@Service
public class KakaoPayServiceImpl implements KakaoService{

	@Autowired
	KakaoPayDAO kakaoPayDAO;
	
	@Override
	public void update(MemberVO memberVO) {
		kakaoPayDAO.update(memberVO);
	}

}
