package com.spring.project.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CartVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.orderListVo;

@Repository
public class ItemDao {

	@Autowired
	SqlSessionTemplate sqlsessionTemplate; 
	
	// 곡 전체 갯수
	public int itemCount(CriteriaVO cri) {
		return sqlsessionTemplate.selectOne("allItemCount",cri);
	}

	// 곡 전체 리스트
	public  List<ItemVo> ItemList() {
		return sqlsessionTemplate.selectList("newItem");
	}
	
	// 장르 전체 리스트
	public List<ItemVo> newGenreList(Map<String, Object> map) {
		return sqlsessionTemplate.selectList("genreList",map);
	}

	// 조회 수 증가
	public void addViewCount(int itemID) {
		sqlsessionTemplate.update("viewCount",itemID);
	}

	/* 곡 상세페이지 */
	public Map<String, Object> itemDetail(Map<String, Object> map) {
		return sqlsessionTemplate.selectOne("itemDetail", map);
	}

	/* 실시간 차트 - 곡 */
	public List<ItemVo> bestItemList() {
		return sqlsessionTemplate.selectList("bestItemList");		
	}

	/* 아이템 Create */
	public int itemCreate(Map<String, Object> map) {
		return sqlsessionTemplate.insert("itemCreate",map);
	}
	
	/* 아이템에 대한 앨범 정보 */
	public List<ItemVo> albumSelect(ItemVo itemVo) {
		return sqlsessionTemplate.selectOne("albumSelect", itemVo);
	}

	/* 인기음악 */
	public List<ItemVo> randomList() {
		return sqlsessionTemplate.selectList("randomList");
	}
	
	/* 장바구니 Insert*/
	public int cartAdd(CartVo vo) {
		return sqlsessionTemplate.insert("cart",vo);
	}

	/* 마이 페이지 (장바구니 리스트) */
	public List<CartVo> cartList(Map<String, Object> map) {
		return sqlsessionTemplate.selectList("cartList",map);
	}

	public int delynUpdate(CartVo cartVO) {
		return sqlsessionTemplate.update("delynUpdate", cartVO);
	}

	public List<orderListVo> orderList(orderListVo orderListvo) {
		return sqlsessionTemplate.selectList("orderList",orderListvo);
	}

	

}
