package com.spring.project.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.security.Auth;
import com.spring.project.security.Auth.Role;
import com.spring.project.service.AdminService;
import com.spring.project.service.CommonService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ComcodeVo;
import com.spring.project.vo.MemberVO;

@Auth(role = Role.ADMIN)
@Controller
@RequestMapping(value = "/admin")
public class AdminController {

	@Autowired
	AdminService adminService;

	// 관리자 detail 페이지
	@Auth(role = Role.ADMIN)
	@RequestMapping(value = "/userset", method = RequestMethod.GET)
	public ModelAndView adminUserset(MemberVO memberVO) {
		List<MemberVO> data = adminService.adminDetail(memberVO);

		ModelAndView ma = new ModelAndView();
		ma.addObject("data", data);
		ma.setViewName("admin/adminDetail");
		return ma;
	}

	// 관리자 detail : update 페이지
	@Auth(role = Role.ADMIN)
	@RequestMapping(value = "/userset", method = RequestMethod.POST)
	public String adminUsersetPost(MemberVO memberVO, HttpServletRequest request) throws Exception {
		adminService.adminUpdate(memberVO);
		String referer = request.getHeader("Referer");
		return "redirect:" + referer;

	}

	@Auth(role = Role.ADMIN)
	@GetMapping("/main")
	public String adminmain() {
		return "admin/adminMainpage";
	}
	

	// 관리자 detail 페이지
	@Auth(role = Role.MANAGER)
	@RequestMapping(value = "/manager", method = RequestMethod.GET)
	public ModelAndView managerSet(AlbumVo albumVo) {
		List<AlbumVo> data = adminService.managerProduct(albumVo);
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", data);
		ma.setViewName("admin/managerProduct");
		return ma;
	}

	// 관리자 detail : update 페이지
	@Auth(role = Role.MANAGER)
	@RequestMapping(value = "/manager", method = RequestMethod.POST)
	public String managerSetPost(AlbumVo albumVo, HttpServletRequest request) throws Exception {
		adminService.managerProductUpdate(albumVo);
		String referer = request.getHeader("Referer");
		return "redirect:" + referer;

	}

	// 관리자 detail : insert 페이지
	@Auth(role = Role.MANAGER)
	@RequestMapping(value = "/managerinsert", method = RequestMethod.POST)
	public ModelAndView managerSetInsert(HttpServletRequest request, @RequestParam Map<String,Object> map) throws Exception {
		adminService.managerProductInsert(map);
		String referer = request.getHeader("Referer");
		return new ModelAndView("redirect:"+referer);

	}

	
}
