package com.spring.project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class RootController {
	@GetMapping("/")
	public ModelAndView rootpage() {
		return new ModelAndView("test/rootpage");
	}
	
	
	/*
	 * @PostMapping("/") public ModelAndView mainpagePost(@RequestParam String
	 * id, @RequestParam String password, HttpSession session) {
	 * System.out.println(id); System.out.println(password);
	 * 
	 * // 추후 SQL에서 정보 받아오는 코드로 변경 if (id.equals("admin") && password.equals("1234"))
	 * { String type = "000"; System.out.println(type); if (type.equals("000")){
	 * session.setAttribute("id", "admin");// 세션 셋팅 return new
	 * ModelAndView("test/success"); }
	 * 
	 * } return new ModelAndView("test/test"); }
	 */
}
