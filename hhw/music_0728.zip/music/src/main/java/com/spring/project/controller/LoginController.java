package com.spring.project.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.vo.LoginVo;


@Controller
public class LoginController {

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(Model model) {
		LoginVo vo = new LoginVo();
		model.addAttribute("userForm", vo);
		return new ModelAndView("login/login");
		
	
	}
	
	/* 백업
	 * @RequestMapping(value = "/login", method = RequestMethod.POST) public String
	 * loginPost(@Valid @ModelAttribute("userForm") LoginVo vo, BindingResult
	 * result) { if(result.hasErrors()) { return "login/login"; } return
	 * "redirect:/"; }
	 */
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPost(@Valid @ModelAttribute("userForm") LoginVo vo, BindingResult result) {
		if(result.hasErrors()) {
			return "login/login";
		}
		return "redirect:/";
	}

}
