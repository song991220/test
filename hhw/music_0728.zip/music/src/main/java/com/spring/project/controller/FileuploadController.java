package com.spring.project.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.Filevo;
import com.spring.project.PersonForm;

@Controller
public class FileuploadController {
	@Autowired
	ServletContext context;
	
	
	@RequestMapping(value = "/fileupload", method = RequestMethod.GET)
	public ModelAndView fileuplaod() {
		//FileCopyUtils.copy(null, null)
		Filevo file = new Filevo();
		return new ModelAndView("temp/fileupload","command",file);
	}
	
	@RequestMapping(value = "/fileupload", method = RequestMethod.POST)
	public ModelAndView fileuplaodPost(@Valid Filevo file,
			BindingResult result/* , ModelMap model */) throws IOException 
	{	
		
		if(result.hasErrors()) {			
			System.out.println("validation error");			
			return new ModelAndView("temp/fileupload"); 
		}
		else {	
			System.out.println(file.getContent());
			
			MultipartFile multipartFile = file.getFile();
			String uploadPath = context.getRealPath(File.separator)+"/resources/"; //context.getRealPath("") + File.separator + "temp" + File.separator;	
			FileCopyUtils.copy(file.getFile().getBytes(), new File(uploadPath + "/"+file.getFile().getOriginalFilename())); 
			String fileName = multipartFile.getOriginalFilename();
//			model.addAttribute("filename",fileName);
			
			System.out.println(uploadPath);
			System.out.println(multipartFile.getOriginalFilename());			
			System.out.println(file);
			
			ModelAndView mv = new ModelAndView();
			mv.setViewName("temp/success");
			mv.addObject("fileName",file.getFile().getOriginalFilename());
			return mv;
		}		
	
	}
	
	@GetMapping("/person")
	public String check() {
		return "person";
	}
	
	@PostMapping("/person")
	public String checkpost(@Valid PersonForm personForm, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors()) {
			for (ObjectError iterable_element : bindingResult.getAllErrors()) {
				System.out.println(iterable_element.getDefaultMessage());
				
			}
			System.out.println("error 발생....");
			return "person";
		}

		return "redirect:/";
	}
	
	
}
