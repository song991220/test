package com.spring.project.service;

import java.util.List;

import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;

public interface ItemService {

	int countItemList();

	List<ItemVo> newItemList(CriteriaVO cri);

}
