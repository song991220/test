package com.spring.project.kakaopay;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.project.vo.MemberVO;

import lombok.Setter;
import lombok.extern.java.Log;

@Log
@Controller
public class KakaoPayController {

	@Setter(onMethod_ = @Autowired)
	private KakaoPay kakaopay;
	

	@Autowired
	KakaoService kakaoService;

	@GetMapping("/kakaopay")
	public String kakaoPayGet(HttpSession session) {
		System.out.println("kakaopay called..................................");
		return "kakaopay/kakaopay";
	}

	@PostMapping("/kakaopay")
	public String kakaoPay() {
		log.info("kakaoPay post............................................");

		return "redirect:" + kakaopay.kakaoPayReady();

	}

	@GetMapping("/kakaopaysuccess")
	public void kakaoPaySuccess(@RequestParam("pg_token") String pg_token, Model model) {
		log.info("kakaoPaySuccess get............................................");
		log.info("kakaoPaySuccess pg_token : " + pg_token);

	}

	@RequestMapping(value = "/success")
	public String success(@RequestParam("pg_token") String pg_token, Model model, HttpSession session, MemberVO memberVO) {
		
		memberVO.setId((String)session.getAttribute("id"));
		kakaoService.update(memberVO);
		log.info("프리미엄 회원으로 변경 성공");
		
		log.info("kakaoPaySuccess get............................................");
		log.info("pg_token : " + pg_token);
		model.addAttribute("info", kakaopay.kakaoPayInfo(pg_token));
		return "/kakaopay/success";
	}

	@RequestMapping(value = "/fail")
	public String fail() {
		return "/kakaopay/fail";
	}

	@RequestMapping(value = "/cancel")
	public String cancel() {
		return "/kakaopay/cancel";
	}

	
	@RequestMapping(value = "/successtest")
	public String successTest() {
		return "/kakaopay/success";
	}

}
