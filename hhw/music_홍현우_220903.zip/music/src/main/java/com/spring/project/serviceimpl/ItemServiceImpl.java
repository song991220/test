package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.ItemDao;
import com.spring.project.service.ItemService;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemDao itemDao;
	
	// 곡 전체 갯수
	@Override
	public int countItemList(CriteriaVO cri) {
		return itemDao.itemCount(cri);
	}
	
	// 곡 전체 리스트
	@Override
	public List<ItemVo> newItemList() {
		return itemDao.ItemList();
	}
	
	// 장르 리스트
	@Override
	public List<ItemVo> newgenreList(Map<String, Object> map) {
		return itemDao.newGenreList(map);
	}
	
	// 곡 조회수
	@Override
	public void viewCount(int itemID) {
		itemDao.addViewCount(itemID);
	}

	/* 곡 상세페이지 */
	@Override
	public Map<String, Object> detail(Map<String, Object> map) {
		return itemDao.itemDetail(map);
	}

	/* 실시간 음악 - 곡 */
	@Override
	public List<ItemVo> bestItemList() {
		return itemDao.bestItemList();
	}

	/* 아이템 Create */
	@Override
	public int itemCreate(Map<String, Object> map) {
		return itemDao.itemCreate(map);
	
	}

	/* 인기음악 */
	@Override
	public List<ItemVo> randomList() {
		return itemDao.randomList();
	}

	
	

}
