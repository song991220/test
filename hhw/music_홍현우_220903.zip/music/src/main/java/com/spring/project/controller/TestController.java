package com.spring.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {

	@RequestMapping("/audiotest")
	public String audioTest() {
		return "audioTest";
	}	
	
	@RequestMapping("/audiotest2")
	public String audioTest2() {
		return "audioTest2";
	}	
	
	
	@RequestMapping("/audiotest3")
	public String audioTest3() {
		return "audioTest3";
	}	
	
	@RequestMapping("/errortest")
	public String errorTest1() {
		int a = 1/0;
		return "확인용";
	}
	
	@RequestMapping(value="/popup", method=RequestMethod.GET)
	public ModelAndView popupGet(Model model) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("popup");
		System.out.println("Popup1");
		
		return mav;
	}
}
