/**
 * 
 */

const myAudio = document.getElementById("myAudio");


// myAudio.play();


// btn1을 눌렀을 때 sound1.mp3 재생
document.querySelector(".btn1").addEventListener("click", function() {

	var audio1 = new Audio();
	audio1.src = "/resources/mp3/sound1.mp3";
	audio1.loop = false; // 반복재생하지 않음
	audio1.volume = 0.5; // 음량 설정
	audio1.play(); // sound1.mp3 재생
	
	setTimeout(function() {
		console.log('5초 미리듣기');
		audio1.pause();
		alert("5초 미리듣기 끝");
	}, 5000);


});



