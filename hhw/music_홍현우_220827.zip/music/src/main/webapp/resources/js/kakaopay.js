/**
 * 
 */

$(function() {
	$('#apibtn').click(function() {
		$.ajax({
			url : '/kakaopay/kakaopay' ,
			dataType:'json',
			success:function(data){
				// 결제 고유 번호, 20자
				// alert(data.tid);
				// 요청한 클라이언트가 PC 웹일 경우
				//alert(data.next_redirect_pc_url);
				var box = data.next_redirect_pc_url;
				window.open(box);
			},
			error:function(error){
				alert(error);
			}
		});
	});
});