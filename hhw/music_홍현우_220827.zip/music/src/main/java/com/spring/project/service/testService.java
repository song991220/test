package com.spring.project.service;

import java.util.List;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ItemVo;

public interface testService {

	List<AlbumVo> testList();

	List<ItemVo> testItemList();

}
