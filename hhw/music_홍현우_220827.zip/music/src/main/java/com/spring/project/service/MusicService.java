package com.spring.project.service;

import java.util.List;

import com.spring.project.vo.ComcodeVo;

public interface MusicService {
	List<ComcodeVo> getComcodeLists();
}
