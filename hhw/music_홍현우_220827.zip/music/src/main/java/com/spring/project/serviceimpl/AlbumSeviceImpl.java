package com.spring.project.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.spring.project.dao.AlbumDao;
import com.spring.project.service.AlbumService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;

@Service
public class AlbumSeviceImpl implements AlbumService{
	
	@Autowired
	ServletContext context;
	
	@Autowired
	AlbumDao albumDao;
	

	// 앨범 전체 리스트
	@Override
	public List<AlbumVo> selectAlbumList(CriteriaVO cri) {
		return albumDao.selectAlbumList(cri);
	}

	// 앨범 생성
	@Override
	public int create(AlbumVo vo) {
		return albumDao.insert(vo);
	}
		
	// 앨범 상세
	@Override
	public Map<String, Object> detail(Map<String, Object> map) {
		return albumDao.detail(map);
	}

	// 앨범 수정
	@Override
	public boolean update(Map<String, Object> map) {
		return albumDao.update(map) == 1;
	}
	
	// 앨범 삭제
	@Override
	public boolean delete(Map<String, Object> map) {
		return albumDao.delete(map)==1;
	}
	
	// 앨범 전체 갯수
	@Override
	public int countAlbumList() {
		return albumDao.allAlbumCount();
	}

	
}
