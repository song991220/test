package com.spring.project.controller;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping(value = "/kakaopay2")
public class KakaopayController {
	
	private Logger logger = LoggerFactory.getLogger(KakaopayController.class);

	// /kakaopay/pay, /kakaopay/fail, /kakaopay/cancel 만들기

	@RequestMapping(value = "/Test")
	public ModelAndView main(ModelAndView mv, HttpSession session, RedirectView redirectView) {
		mv.setViewName("/kakaopay/kakaopayTest");
		return mv;
	}

	/** 카카오 api */
	@RequestMapping(value = "/kakaopay")
	@ResponseBody
	public String kakaopay() {
		try {
			URL url = new URL("https://kapi.kakao.com/v1/payment/ready");
			HttpURLConnection serverConnection = (HttpURLConnection) url.openConnection();
			serverConnection.setRequestMethod("POST");
			serverConnection.setRequestProperty("Authorization", "KakaoAK 4be2b0b68b9227cfcad3a7c7f6e650be");
			serverConnection.setRequestProperty("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
			serverConnection.setDoOutput(true);
			String param = "cid=TC0ONETIME&partner_order_id=partner_order_id&partner_user_id=partner_user_id&item_name=engitem&quantity=1&total_amount=2200&tax_free_amount=0&approval_url=http://localhost/kakaopay/success&fail_url=http://localhost/kakaopay/fail&cancel_url=http://localhost/kakaopay/cancel";
			OutputStream outPutStream = serverConnection.getOutputStream();
			DataOutputStream dataOutputStream = new DataOutputStream(outPutStream);
			dataOutputStream.writeBytes(param);

			/*
			 * 데이터를 보냄으로써 비워내는 함수 flush dataOutputStream.flush(); .close() 에는 flush() 가 포함되어
			 * 있다.
			 */
			dataOutputStream.close();

			int result = serverConnection.getResponseCode();

			InputStream inputStream;

			/** http 통신에서 정상적인 통신을 뜻하는 코드가 200 */
			if (result == 200) {
				inputStream = serverConnection.getInputStream();
			} else {
				inputStream = serverConnection.getErrorStream();
			}

			InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

			/** 형변환 하는 함수 */
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			return bufferedReader.readLine();

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "[\"result\":\"NO\"]";
	}

	@RequestMapping(value = "/success")
	public String success(@RequestParam("pg_token") String pg_token) {
		logger.info("pg_token : "+pg_token);
		return "/kakaopay/success";
	}
	
	@RequestMapping(value = "/fail")
	public String fail() {
		return "/kakaopay/fail";
	}

	@RequestMapping(value = "/cancel")
	public String cancel() {
		return "/kakaopay/cancel";
	}
}
