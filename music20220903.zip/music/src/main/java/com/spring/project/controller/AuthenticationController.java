package com.spring.project.controller;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthenticationController {
	// --------------------------- auth -----------------------------------
		@GetMapping("/accessError")
		public ModelAndView accessDenied(Authentication auth, Model model) {
			System.out.println("access Denied : " + auth);
			model.addAttribute("msg", "접근 권한 거부");
			ModelAndView ma = new ModelAndView();
			ma.setViewName("common/accessError");
			return ma;
		}
		@GetMapping("/customLogin")
		public ModelAndView loginInput(String error, String logout, Model model) {
			System.out.println("error : "+ error);
			System.out.println("logout : "+ logout);
			if (error != null) {
				model.addAttribute("error", "Login Error Check Your Account");
			}
			if (logout != null) {
				model.addAttribute("logout", "Logout!!");
			}
			 return new ModelAndView("login/customLogin"); 
		}
		
		@GetMapping("/customLogout")
		public ModelAndView logoutGET() {
			ModelAndView ma = new ModelAndView();
			System.out.println("GET : custom logout");
			ma.setViewName("login/customLogout");
			return ma;
		}
		
		@PostMapping("/customLogout")
		public ModelAndView logoutPOST() {
			ModelAndView ma = new ModelAndView();
			System.out.println("POST : custom logout");
			ma.setViewName("login/customLogout");
			return ma;
		}
		

}
