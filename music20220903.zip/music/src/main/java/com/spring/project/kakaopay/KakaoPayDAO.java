package com.spring.project.kakaopay;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.MemberVO;


@Repository
public class KakaoPayDAO {
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	// sql 경로를 설정
	private static String namespace = "kakaopay";
	

	public void update(MemberVO memberVO) {

		System.out.println("kakaopayDAO 확인값 : " + namespace + ".update" + ", id : " + memberVO);
		sqlSessionTemplate.update(namespace + ".update", memberVO);
	}

}
