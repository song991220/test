package com.spring.project.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;

public interface AlbumService {

	/* 앨범 전체 리스트 */
	List<AlbumVo> selectAlbumList(CriteriaVO cri);

	int create(AlbumVo vo);

	Map<String, Object> detail(Map<String, Object> map);

	boolean update(Map<String, Object> map);

	boolean delete(Map<String, Object> map);

	/* 앨범 총 수 */
	int countAlbumList();

	/* 실시간 차트 - 앨범 */
	List<AlbumVo> bestAlbumList();
	
}
