package com.spring.project.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.ItemDao;
import com.spring.project.service.ItemService;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemDao itemDao;
	
	// 곡 전체 갯수
	@Override
	public int countItemList() {
		return itemDao.itemCount();
	}
	
	// 곡 전체 리스트
	@Override
	public List<ItemVo> newItemList(CriteriaVO cri) {
		return itemDao.ItemList(cri);
	}

}
