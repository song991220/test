package com.spring.project.util;

import javax.servlet.http.HttpSession;

public class SessionAssignment {

	// SQL 에서 로그인 가능한지 확인 후 넘어오는 값
	public void sessionAssignment(String id, HttpSession session) {
		if (session.getAttribute("id") != null) { // 만약 세션 정보가 있다면
			session.removeAttribute("id"); // 일단 이전 로그인 세션 정보를 제거한다.
		}
		session.setAttribute("id", id); // 세션 값 할당
		
	}

}
