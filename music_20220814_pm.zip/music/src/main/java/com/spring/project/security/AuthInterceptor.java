package com.spring.project.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.spring.project.security.Auth.Role;
import com.spring.project.vo.MemberVO;

public class AuthInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// 1. handler 종류 확인
		// 관심있는 것은 Controller 에 있는 메서드 이므로 HandlerMethod 타입인지 체크
		if (handler instanceof HandlerMethod == false) {
			// return 이 true 이면 Controller 에 있는 메서드가 아니므로, 그대로 컨트롤러로 진행
			return true;
		}

		// 2. 형변환
		HandlerMethod handlerMethod = (HandlerMethod) handler;

		// 3. Auth 받아오기
		Auth auth = handlerMethod.getMethodAnnotation(Auth.class);
		Auth adminRole = handlerMethod.getMethod().getDeclaringClass().getAnnotation(Auth.class);

		// 4. method 에 @Auth가 없는 경우, 즉 인증이 필요 없는 요청
		if (auth == null) {
			return true;
		}

		// 5. @Auth 가 있는 경우이므로, 세션이 있는지 체크
		HttpSession session = request.getSession();
		if (session == null) {
			// 로그인 화면으로 이동
			response.sendRedirect(request.getContextPath() + "/member/login");
			return false;
		}

		// 6. 세션이 존재하면 유효한 유저인지 확인
		String authUser = (String) session.getAttribute("membership");
		if (authUser == null) {
			response.sendRedirect(request.getContextPath() + "/member/login");
			return false;
		}
		boolean adminAuth = "001".equals(authUser) == true;
		boolean managerAuth = "002".equals(authUser) == true;
		boolean premium_userAuth = "003".equals(authUser) == true;
		boolean userAuth = "004".equals(authUser) == true;
		
		
		// 7. admin일 경우
//		if (adminRole != null) {
		if (auth != null) {
			String role = auth.role().toString();
			
			// 	@Auth(role = Role.ADMIN) 이라면?
			if ("ADMIN".equals(role)) {
				
				// admin 임을 알 수 있는 조건을 작성한다
				// ex) membership 의 값이 "001" 이면 admin이다
				if ("001".equals(authUser) == true) { // admin 이 아니므로 return false
//					response.sendRedirect(request.getContextPath() + "/member/loginCheck");
					return true;
				}
			}
			// 	@Auth(role = Role.MANAGER) 이거나 아이디.sesssion의 membership 값이 001 이라면?
			if ("MANAGER".equals(role) || adminAuth) {
				if ("002".equals(authUser) == true || adminAuth)  {
					return true;
				}
			}
			
			// 	@Auth(role = Role.PREMIUM_USER) 이거나 아이디.sesssion의 membership 값이 001,002 이라면?
			if ("PREMIUM_USER".equals(role) || adminAuth || managerAuth) {
				if ("003".equals(authUser) == true || adminAuth || managerAuth) {
					return true;
				}
			}
			
			// 	@Auth(role = Role.USER) 혹은 @Auth 이거나 아이디.sesssion의 membership 값이 001,002,003 이라면?
			if ("USER".equals(role) == true || adminAuth || managerAuth || premium_userAuth) {
				if ("004".equals(authUser) == true || adminAuth || managerAuth || premium_userAuth ) {
					return true;
				}
			}
			response.sendRedirect(request.getContextPath() + "/member/noauth");
			return false;
		}
		/*
		 * if ("MANAGER".equals(role)) { // manager 임을 알 수 있는 조건을 작성한다 // ex) membership
		 * 의 값이 "002" 이면 manager이다 if ("002".equals(authUser) == false ||
		 * "001".equals(authUser) == false) {
		 * response.sendRedirect(request.getContextPath()+"/member/loginCheck"); return
		 * false; } }
		 */

//		}
		// 8. 접근허가, 즉 메서드를 실행하도록 함
		return true;
	}

}
