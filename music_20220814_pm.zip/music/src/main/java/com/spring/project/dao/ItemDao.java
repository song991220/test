package com.spring.project.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;

@Repository
public class ItemDao {

	@Autowired
	SqlSessionTemplate sqlsessionTemplate; 
	
	// 곡 전체 갯수
	public int itemCount(CriteriaVO cri) {
		return sqlsessionTemplate.selectOne("allItemCount",cri);
	}

	// 곡 전체 리스트
	public  List<ItemVo> ItemList() {
		return sqlsessionTemplate.selectList("newItem");
	}

	
	// 장르 전체 리스트
	public List<ItemVo> newGenreList(Map<String, Object> map) {
		return sqlsessionTemplate.selectList("genreList",map);
	}
	

}
