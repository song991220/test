package com.spring.project.kakaopay;

import com.spring.project.vo.MemberVO;

public interface KakaoService {
	
	public void update(MemberVO memberVO);
	
}
