package com.spring.project.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestParam;

import com.spring.project.vo.CartVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.orderListVo;

public interface ItemService {
	
	/* 곡 리스트 */
	List<ItemVo> newItemList();
	
	/* 곡 전체 갯수 */
	int countItemList(CriteriaVO cri);
	
	/* 곡 조회수 */
	void viewCount(int itemID);

	/* 아이템 Detail */
	Map<String, Object> detail(Map<String, Object> map);

	/* 아이템 Create */
	int itemCreate(Map<String, Object> map);
	
	/* 아이템에 대한 앨범 정보 (필요없음) */
	List<ItemVo> albumSelect(ItemVo itemVo);
	
	/* 장르 리스트 */
	List<ItemVo> newgenreList(Map<String, Object> map);

	/* 실시간 차트 - 곡 */
	List<ItemVo> bestItemList();
	
	/* 인기음악 */
	List<ItemVo> randomList();

	/* 장바구니 Insert*/
	void cartInsert(CartVo vo);

	/* 마이 페이지 (장바구니 리스트) */
	List<CartVo> cartList(Map<String, Object> map);

	/* 장바구니 아이템 성공시 업데이트 */
	void delynUpdate(CartVo cartVO);

	/* 주문내역 */
	List<orderListVo> orderList(orderListVo orderListvo);


	



}
