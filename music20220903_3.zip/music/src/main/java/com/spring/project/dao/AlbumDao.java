package com.spring.project.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;


@Repository
public class AlbumDao {

	private static String namespace = "album";
	
	@Autowired
	SqlSessionTemplate sqlsessionTemplate;
	
	// 앨범 전체 리스트
	public List<AlbumVo> selectAlbumList(CriteriaVO cri) {
		return sqlsessionTemplate.selectList(namespace+".selectAlbum",cri);
	}

	// 앨범 생성
	public int insert(AlbumVo vo) {
		return sqlsessionTemplate.insert("insertAlbum",vo);
	}

	// 앨범 상세
	public Map<String, Object> detail(Map<String, Object> map) {
		return sqlsessionTemplate.selectOne("detailAlbum",map);
	}

	// 앨범 수정
	public int update(Map<String, Object> map) {
		return sqlsessionTemplate.update("updateAlbum", map);
	}

	// 앨범 삭제
	public int delete(Map<String, Object> map) {
		return sqlsessionTemplate.delete("deleteAlbum", map);
	}
	
	// 앨범 전체 갯수
	public int allAlbumCount() {
		return sqlsessionTemplate.selectOne("allAlbumCount");
	}

	/* 실시간 차트 - 앨범 */
	public List<AlbumVo> bestAlbumList() {
		return sqlsessionTemplate.selectList("bestAlbumList");
	}

	
}
