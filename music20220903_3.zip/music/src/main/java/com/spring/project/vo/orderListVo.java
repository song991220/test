package com.spring.project.vo;

import lombok.Getter;
import lombok.Setter;

public class orderListVo {
	
	@Getter
	@Setter
	private int id, item_id, albumid, viewCount, itemID,rownum; 
	
	@Getter
	@Setter
	private String title,reg_date,reg_user,up_user, up_date,member_id, delyn, create_dt,categoryid,albumTitle,singersong,itemTitle,image;
	

}
