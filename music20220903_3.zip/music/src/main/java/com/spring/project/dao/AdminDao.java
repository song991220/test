package com.spring.project.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ComcodeVo;
import com.spring.project.vo.MemberVO;

@Repository
public class AdminDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	// sql 경로를 설정
	private static String namespace = "admin";

	public List<MemberVO> detail(MemberVO memberVO) {
		return sqlSessionTemplate.selectList(namespace + ".detail", memberVO);
	}
	


	public void update(MemberVO memberVO) {
		System.out.println("확인값 : " + namespace + ".update" + ", vo : " + memberVO);
		sqlSessionTemplate.update(namespace + ".update", memberVO);
	}

	public List<AlbumVo> managerProduct(AlbumVo albumVo) {
		return sqlSessionTemplate.selectList(namespace + ".managerProduct", albumVo);
	}

	public void managerProductUpdate(AlbumVo albumVo) {
		System.out.println("확인값 : " + namespace + ".managerProductUpdate" + ", vo : " + albumVo);
		sqlSessionTemplate.update(namespace + ".managerProductUpdate", albumVo);
	}

// 매니저 상품관리 추가
	public void managerProductInsert(Map<String, Object> map) {
		System.out.println(map);
//		System.out.println(sqlSessionTemplate.insert("insertComcode", map));
		sqlSessionTemplate.insert("managerProductInsert", map);
	}

}
