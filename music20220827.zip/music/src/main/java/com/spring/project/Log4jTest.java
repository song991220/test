package com.spring.project;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log4jTest {
	
	private Logger log = LoggerFactory.getLogger(Log4jTest.class);
	
	public static void main(String[] args) {
		new Log4jTest().test();
	}
	
	public void test() {
		log.debug("debug !");
		log.info("info !");
		log.warn("warn !");
		log.error("error !");
	}

}
