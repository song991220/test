package com.spring.project.kakaopay;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.project.service.ItemService;
import com.spring.project.vo.CartVo;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.MemberVO;

import lombok.Setter;
import lombok.extern.java.Log;

@Log
@Controller
public class KakaoPayController {

	@Setter(onMethod_ = @Autowired)
	private KakaoPay kakaopay;

	@Autowired
	KakaoService kakaoService;
	
	@Autowired
	ItemService itemService;

	@GetMapping("/kakaopay")
	public String kakaoPayGet(HttpSession session) {
		System.out.println("kakaopay called..................................");
		return "kakaopay/kakaopay";
	}

	@PostMapping("/kakaopay")
	public String kakaoPay() {		
		log.info("kakaoPay post............................................");
		return "redirect:" + kakaopay.kakaoPayReady();

	}
	
	@PostMapping("/kakaopay2")
	@ResponseBody
	public String kakaoPay2(@RequestParam("data") String t,HttpSession session) {		
		log.info("kakaoPay2 post  " + t);
		if("[]".equals(t))
			session.removeAttribute("musiclist");
		else
			session.setAttribute("musiclist", t);
		
		return kakaopay.kakaoPayReady();
	}

	@GetMapping("/kakaopaysuccess")
	public void kakaoPaySuccess(@RequestParam("pg_token") String pg_token, Model model) {
		log.info("kakaoPaySuccess get............................................");
		log.info("kakaoPaySuccess pg_token : " + pg_token);

	}

	@RequestMapping(value = "/success")
	public String success(@RequestParam("pg_token") String pg_token, Model model, HttpSession session, MemberVO memberVO, CartVo cartVO) {
		/*
		 * try { String musiclist = (String)session.getAttribute("musiclist");
		 * 
		 * String str = musiclist.replaceAll("[^0-9]", ","); String[] arystr =
		 * str.split(",");
		 * 
		 * List<Integer> lists = new ArrayList<Integer>(); for (String s : arystr) { try
		 * { int data = Integer.valueOf(s); lists.add(data); }catch (Exception e) {} }
		 * 
		 * if(!"[]".equals(musiclist)) {
		 * 
		 * String session_id =v;
		 * cartVO.setMember_id(session_id); itemService.delynUpdate(cartVO);
		 * 
		 * } }catch (Exception e) { e.printStackTrace(); }
		 */
		
		String musiclist = (String)session.getAttribute("musiclist");
		if(musiclist != null) {
			System.out.println("--------------------------------------");
		}
		else {
			memberVO.setId((String)session.getAttribute("id"));
			kakaoService.update(memberVO);
			log.info("프리미엄 회원으로 변경 성공");
			
			log.info("kakaoPaySuccess get............................................");
			log.info("pg_token : " + pg_token);
			model.addAttribute("info", kakaopay.kakaoPayInfo(pg_token));
		}
		
		return "/kakaopay/success";
	}

	@RequestMapping(value = "/fail")
	public String fail() {
		return "/kakaopay/fail";
	}

	@RequestMapping(value = "/cancel")
	public String cancel() {
		return "/kakaopay/cancel";
	}

	
	@RequestMapping(value = "/successtest")
	public String successTest() {
		return "/kakaopay/success";
	}

}
