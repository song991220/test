package com.spring.project.service;

import java.util.List;
import java.util.Map;

import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ComcodeVo;
import com.spring.project.vo.MemberVO;

public interface AdminService {

	public List<MemberVO> adminDetail(MemberVO memberVO);
	

	public void adminUpdate(MemberVO memberVO);

	public List<AlbumVo> managerProduct(AlbumVo albumVo);


	public void managerProductUpdate(AlbumVo albumVo);
	
//	manager 상품관리 페이지 추가
	void managerProductInsert(Map<String, Object> map);
}
