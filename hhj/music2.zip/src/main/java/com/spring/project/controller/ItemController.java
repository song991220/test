package com.spring.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.ItemService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.PagingVo;

@Controller
public class ItemController {
	
	@Autowired
	ItemService itemService;
	
	// 앨범에 따른 곡 전체리스트(+페이징,최신순)
	@RequestMapping(value = "/newItemList", method = RequestMethod.GET)
	public ModelAndView newItemList(CriteriaVO cri) {
		
		ModelAndView ma = new ModelAndView();
		PagingVo paging = new PagingVo();
		
		paging.setCri(cri);
		paging.setTotalCount(itemService.countItemList());
		
		List<ItemVo> list = itemService.newItemList(cri);
		
		ma.addObject("paging", paging);
		ma.addObject("list",list);
		ma.setViewName("/album/itemList");
		
		return ma;
	}
		
}
