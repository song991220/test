package com.spring.project.service;

import java.util.List;
import java.util.Map;

import com.spring.project.vo.AlbumVo;

public interface AlbumService {

	List<AlbumVo> selectAlbumList();

	String create(Map<String, Object> map);

	Map<String, Object> detail(Map<String, Object> map);

	boolean update(Map<String, Object> map);

	boolean delete(Map<String, Object> map);

	int countAlbumList();

	
}
