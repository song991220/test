package com.spring.project.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.AlbumDao;
import com.spring.project.dao.ItemDao;
import com.spring.project.service.testService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ItemVo;

@Service
public class testServiceImpl implements testService {

	@Autowired
	AlbumDao albumDao;
	
	@Autowired
	ItemDao itemDao;
	
	@Override
	public List<AlbumVo> testList() {
		return albumDao.testSelect();
	}

	@Override
	public List<ItemVo> testItemList() {
		return itemDao.testItemSelect();
	}

}
