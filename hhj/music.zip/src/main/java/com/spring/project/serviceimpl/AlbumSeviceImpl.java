package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.AlbumDao;
import com.spring.project.service.AlbumService;
import com.spring.project.vo.AlbumVo;

@Service
public class AlbumSeviceImpl implements AlbumService{
	
	@Autowired
	AlbumDao albumDao;

	@Override
	public List<AlbumVo> selectAlbumList() {
		return albumDao.selectAlbumList();
	}

	@Override
	public String create(Map<String, Object> map) {
		int cnt =  albumDao.insert(map);
		if(cnt == 1)
			return map.get("album_id").toString();
		return null;
	}

	@Override
	public Map<String, Object> detail(Map<String, Object> map) {
		return albumDao.detail(map);
	}

	@Override
	public boolean update(Map<String, Object> map) {
		return albumDao.update(map) == 1;
	}

	@Override
	public boolean delete(Map<String, Object> map) {
		return albumDao.delete(map)==1;
	}		
	
	
}
