package com.spring.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.AlbumService;
import com.spring.project.vo.AlbumVo;

@Controller
public class AlbumController {
	
	@Autowired
	AlbumService albumservice;
	
	
	@RequestMapping(value = "/albumList")
	public  ModelAndView albumList() {
		List<AlbumVo> lists = albumservice.selectAlbumList(); 
		ModelAndView ma = new ModelAndView();
		ma.addObject("lists",lists);
		ma.setViewName("album/albumList");
		return ma;
	}
	
	@RequestMapping(value = "/albumCreate", method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("album/create");
	}
	
	@RequestMapping(value =  "/albumCreate", method = RequestMethod.POST )
	public ModelAndView albumCreate(@RequestParam Map<String, Object> map) {
		ModelAndView ma = new ModelAndView();
		String id = albumservice.create(map);
		if(id == null)
			ma.setViewName("redirect:/create");
		else
			ma.setViewName("redirect:/albumList");  
		return ma;
	}
	
	@RequestMapping(value = "/albumDetail", method=RequestMethod.GET)
	public ModelAndView albumDetail(@RequestParam Map<String , Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/detail");
		return ma;
	}
	
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.GET)
	public ModelAndView albumUpdateView(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);
		
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/update");
		
		return ma;
	}
	
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.POST)
	public ModelAndView albumUpdate(@RequestParam Map<String, Object> map) {
		boolean isSuccess = albumservice.update(map);
		ModelAndView ma = new ModelAndView();
		
		if(isSuccess)
			ma.setViewName("redirect:/albumList");
		else
			ma = albumUpdateView(map);
		
		return ma;
	}
	
	@RequestMapping(value = "/albumDelete", method = RequestMethod.GET)
	public ModelAndView albumDelete(@RequestParam Map<String, Object> map) {
		ModelAndView ma = new ModelAndView();
		AlbumVo vo = new AlbumVo();
		
		boolean isSuccess = albumservice.delete(map);
		
		if(isSuccess)
			ma.setViewName("redirect:/albumList");
		else 
			ma.setViewName("/albumDelete?albumID="+vo.getId());
			
		return ma;
	}
	
}
