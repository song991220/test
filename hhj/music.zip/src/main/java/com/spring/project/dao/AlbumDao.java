package com.spring.project.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.AlbumVo;


@Repository
public class AlbumDao {

	@Autowired
	SqlSessionTemplate sqlsessionTemplate;
	
	public List<AlbumVo> selectAlbumList() {
		return sqlsessionTemplate.selectList("selectAlbum");
	}

	public int insert(Map<String, Object> map) {
		return sqlsessionTemplate.insert("insertAlbum",map);
	}

	public Map<String, Object> detail(Map<String, Object> map) {
		return sqlsessionTemplate.selectOne("detailAlbum",map);
	}

	public int update(Map<String, Object> map) {
		return sqlsessionTemplate.update("updateAlbum", map);
	}

	public int delete(Map<String, Object> map) {
		return sqlsessionTemplate.delete("deleteAlbum", map);
	}

}
