package com.spring.project.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.security.Auth;
import com.spring.project.security.Auth.Role;
import com.spring.project.service.MemberService;
import com.spring.project.util.CommonAuth;
import com.spring.project.vo.MemberVO;

@Controller
@RequestMapping(value = "/member/*")
public class MemberController {

	@Autowired
	MemberService memberService;

	@GetMapping(value = "/login")
	public String login() {
		return "member/login";
	}

	@PostMapping(value = "/loginCheck")
	public ModelAndView login_check(@ModelAttribute MemberVO memberVO, HttpSession session, @RequestParam("id") String id) {
		session.setAttribute("id", id);
		String sessionid = (String) session.getAttribute("id");
		Object name = memberService.memberInfo(sessionid, session, memberVO);
		memberVO = (MemberVO) name;
		System.out.println("controller object name : " + name);
		System.out.println("controller membervo : " + memberVO);
		
		session.setAttribute("id", memberVO.getId()); 
		session.setAttribute("psw", memberVO.getPsw()); 
		session.setAttribute("alies", memberVO.getAlies()); 
		session.setAttribute("membership", memberVO.getMembership()); 
		session.setAttribute("delyn", memberVO.getDelyn());
		session.setAttribute("reg_user", memberVO.getReg_user());
		session.setAttribute("reg_date", memberVO.getReg_date());
		System.out.println("membercontroller memberinfo ------------------------------------------------");
		System.out.println("id : "+session.getAttribute("id"));
		System.out.println("psw : "+session.getAttribute("psw"));
		System.out.println("membership : "+session.getAttribute("membership"));
		System.out.println("alies : "+session.getAttribute("alies"));
		System.out.println("delyn : "+session.getAttribute("delyn"));
		System.out.println("reg_user : "+session.getAttribute("reg_user"));
		System.out.println("reg_date : "+session.getAttribute("reg_date"));
		System.out.println("----------------------------------------------------------------------------");
		
		ModelAndView mv = new ModelAndView();
		//
		//
		if (name != null) { // 로그인 성공 시
			mv.setViewName("member/mainpage"); // 뷰의 이름
			System.out.println("로그인 성공!!!");
		} else { // 로그인 실패 시
			mv.setViewName("member/login");
			mv.addObject("message", "error");
			System.out.println("로그인 실패!!!");
		}
		return mv;
	}

	@Auth(role = Role.USER)
	@GetMapping(value = "/logout")
	public ModelAndView logout(HttpSession session, ModelAndView mav) {
		System.out.println(session.getAttribute("membership"));
		memberService.logout(session);
		mav.setViewName("member/logout");
		mav.addObject("message", "logout");
		return mav;
	}

// 권한 에러 발생시	
	@RequestMapping("/noauth")
	public String auth() {
		return "member/noauth";
	}

	// 회원가입
	@GetMapping("/signUp")
	public String signUp() {
		return "member/signup";
	}

	@PostMapping("/signUp")
	public ModelAndView signUpPost(@RequestParam Map<String, Object> map, String psw, String con_psw) {
		ModelAndView mv = new ModelAndView();

		if (!psw.equals(con_psw)) {
			mv.setViewName("member/signupFail");
			return mv;
		}

		memberService.signUp(map);
		mv.setViewName("member/signupAlert");

		return mv;
	}

	// 비밀번호 찾기
	@GetMapping("/findPw")
	public String findPw() {
		return "member/findPw";
	}

	// 메인페이지 호출
	@Auth
	@GetMapping("/mainpage")
	public String mainPage() {
		return "member/mainpage";
	}

	@Auth
	@GetMapping("/mypage")
	public ModelAndView mypage(MemberVO memberVO, HttpSession session) {
		ModelAndView ma = new ModelAndView();
		ma.setViewName("member/mypage");
		ma.addObject("id", session.getAttribute("id"));
		ma.addObject("psw", session.getAttribute("psw"));
		ma.addObject("reg_date", session.getAttribute("reg_date"));
		return ma;
	}

	@Auth
	@GetMapping("/modify")
	public String memberModify(MemberVO memberVO, HttpSession session) {

		ModelAndView ma = new ModelAndView();
		ma.addObject("id", (String) session.getAttribute("id"));
		ma.addObject("psw", (String) session.getAttribute("psw"));
		ma.addObject("alies", (String) session.getAttribute("psw"));

		return "member/memberModify";
	}
	@Auth
	@PostMapping("/modify")
	public String memberModifyPost(MemberVO memberVO, HttpSession session) {
			memberService.memberModify(memberVO);
			session.setAttribute("psw", memberVO.getPsw());
			session.setAttribute("alies", memberVO.getAlies());
		return "redirect:/member/mypage";
	}
	@Auth
	@GetMapping("/pswconfirm")
	public String pswConfirm() {
		return "member/pswConfirm";
	}
	
	// 아이디 중복 체크
	@PostMapping("/idCheck")
	@ResponseBody
	public int idCheck(@RequestParam("id") String id) {
		String idvalue = memberService.idCheck(id);
		if (idvalue != null || "".equals(idvalue)) {
			return 1;
		}
		return 0;
	}
	

}
