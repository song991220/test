package com.spring.project.vo;


public class MemberVO {
	String id, psw, membership, alies, delyn, reg_user, reg_date, up_user, up_date;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPsw() {
		return psw;
	}

	public void setPsw(String psw) {
		this.psw = psw;
	}

	public String getMembership() {
		return membership;
	}

	public void setMembership(String membership) {
		this.membership = membership;
	}

	public String getAlies() {
		return alies;
	}

	public void setAlies(String alies) {
		this.alies = alies;
	}

	public String getDelyn() {
		return delyn;
	}

	public void setDelyn(String delyn) {
		this.delyn = delyn;
	}

	public String getReg_user() {
		return reg_user;
	}

	public void setReg_user(String reg_user) {
		this.reg_user = reg_user;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

	public String getUp_user() {
		return up_user;
	}

	public void setUp_user(String up_user) {
		this.up_user = up_user;
	}

	public String getUp_date() {
		return up_date;
	}

	public void setUp_date(String up_date) {
		this.up_date = up_date;
	}

	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", psw=" + psw + ", membership=" + membership + ", alies=" + alies + ", delyn="
				+ delyn + ", reg_user=" + reg_user + ", reg_date=" + reg_date + ", up_user=" + up_user + ", up_date="
				+ up_date + "]";
	}

}
