package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.AlbumDao;
import com.spring.project.service.AlbumService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.Criteria;

@Service
public class AlbumSeviceImpl implements AlbumService{
	
	@Autowired
	AlbumDao albumDao;
	
	// 앨범 생성
	@Override
	public String create(Map<String, Object> map) {
		int cnt =  albumDao.insert(map);
		if(cnt == 1)
			return map.get("album_id").toString();
		return null;
	}

	// 앨범 상세
	@Override
	public Map<String, Object> detail(Map<String, Object> map) {
		return albumDao.detail(map);
	}

	// 앨범 수정
	@Override
	public boolean update(Map<String, Object> map) {
		return albumDao.update(map) == 1;
	}
	
	// 앨범 삭제
	@Override
	public boolean delete(Map<String, Object> map) {
		return albumDao.delete(map)==1;
	}

	// 앨범 전체 리스트
	@Override
	public List<AlbumVo> selectAlbumList(Criteria cri) {
		return albumDao.selectAlbumList(cri);
	}

	// 앨범 전체 갯수
	@Override
	public int countAlbumList() {
		return albumDao.allAlbumCount();
	}

	
}
