package com.spring.project.vo;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.lang.NonNull;

public class LoginVo {
	
	@NonNull
	@Email
	private String email;
	
	@NotNull
	private String password;
	
	
	

}
