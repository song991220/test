package com.spring.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.CommonService;
import com.spring.project.vo.ComcodeVo;

@Controller
public class CommonController {
	
	@Autowired
	CommonService commonService;
	
	@RequestMapping(value = "/common", method = RequestMethod.GET)
	public ModelAndView commonCodeVIew() {
		return new ModelAndView("common/common");
	}
	
	@RequestMapping(value = "/common", method = RequestMethod.POST)
	public ModelAndView commonCodeInsert(@RequestParam Map<String,Object> map) {
		commonService.insertComcode(map);
		
		return new ModelAndView("common/common");
	}
	
	@RequestMapping(value = "/commonlist", method = RequestMethod.GET)
	public ModelAndView commonCodelist() {
		List<ComcodeVo> lists = commonService.selectCommonList();
		ModelAndView ma = new ModelAndView();
		ma.addObject("lists",lists);
		ma.setViewName("common/commonlist");
		return ma;
	}
	
	@RequestMapping(value = "/commonupdate", method = RequestMethod.GET)
	public ModelAndView commonCodeUpdate() {
		List<ComcodeVo> lists = commonService.selectCommonList();
		ModelAndView ma = new ModelAndView();
		// ma.addObject("lists",lists);
		ma.setViewName("common/commonModify");
		return ma;
	}
	
	
}
