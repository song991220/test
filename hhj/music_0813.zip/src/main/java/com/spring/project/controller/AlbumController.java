package com.spring.project.controller;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.AlbumService;
import com.spring.project.util.UploadFileUtils;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.PagingVo;

@Controller
public class AlbumController {
	
	@Autowired
	ServletContext servletContext;

	@Autowired
	AlbumService albumservice;
	
	@Resource(name="uploadPath")
	private String uploadPath;
	
	// 앨범 전체 리스트
	@RequestMapping(value = "/newAlbumList", method = RequestMethod.GET)
	public ModelAndView testAlbum(CriteriaVO cri){
		
		ModelAndView ma = new ModelAndView("album/albumList");
		
		int total = albumservice.countAlbumList(cri);
		PagingVo page = new PagingVo(cri, total);
		
		ma.addObject("pageMaker", page);
		
		return ma;
	}
	
	@ResponseBody 
	@RequestMapping(value = "/newAlbumList")
	public List<AlbumVo> testAlbumPost(CriteriaVO cri){
		List<AlbumVo> list = albumservice.selectAlbumList(cri);
		return list;
	}
	

	// 앨범 생성(create)
	@RequestMapping(value = "/albumCreate", method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("album/create");
	}

	@RequestMapping(value =  "/albumCreate", method = RequestMethod.POST )
	public String albumCreate(AlbumVo vo, MultipartFile file) throws Exception {
		
		String imgUploadPath = uploadPath + File.separator + "image";
		String fileName = null;

		if(file != null) {
		 fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes()); 
		} else {
		 fileName = uploadPath + File.separator + "image" + File.separator + "none.png";
		}

		vo.setImg(File.separator + "image" + File.separator + fileName);
		
		albumservice.create(vo);

		return "redirect:/newAlbumList";
	}

	
	// 앨범 상세페이지
	@RequestMapping(value = "/albumDetail", method = RequestMethod.GET)
	public ModelAndView albumDetail(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/detail");
		return ma;
	}

	// 앨범 수정페이지
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.GET)
	public ModelAndView albumUpdateView(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap = albumservice.detail(map);

		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/update");

		return ma;
	}
	
	@RequestMapping(value = "/albumUpdate", method = RequestMethod.POST)
	public ModelAndView albumUpdate(@RequestParam Map<String, Object> map) {
		boolean isSuccess = albumservice.update(map);
		ModelAndView ma = new ModelAndView();

		if (isSuccess)
			ma.setViewName("redirect:/albumList");
		else
			ma = albumUpdateView(map);

		return ma;
	}

	
	// 앨범 삭제
	@RequestMapping(value = "/albumDelete", method = RequestMethod.GET)
	public ModelAndView albumDelete(@RequestParam Map<String, Object> map) {
		ModelAndView ma = new ModelAndView();
		AlbumVo vo = new AlbumVo();

		boolean isSuccess = albumservice.delete(map);

		if (isSuccess)
			ma.setViewName("redirect:/albumList");
		else
			ma.setViewName("/albumDelete?albumID=" + vo.getId());

		return ma;
	}

}
