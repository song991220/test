package com.spring.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

	@RequestMapping("/audiotest")
	public String audioTest() {
		return "audioTest";
	}	
	
	@RequestMapping("/audiotest2")
	public String audioTest2() {
		return "audioTest2";
	}	
	
	@RequestMapping("/errortest")
	public String errorTest1() {
		int a = 1/0;
		return "확인용";
	}
}
