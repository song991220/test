package com.spring.project.controller;

import java.util.Base64;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.project.service.ItemService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;
import com.spring.project.vo.PagingVo;

@Controller
public class ItemController {
	
	@Autowired
	ItemService itemService;
	
	/* 아이템 전체 리스트(GET) */
	@RequestMapping(value = "/newItemList", method = RequestMethod.GET)
	public ModelAndView newItem(){
		return new ModelAndView("album/albumList");
	}
	
	/* 아이템 전체 리스트(POST) */
	@ResponseBody 
	@RequestMapping(value = "/newItemList")
	public List<ItemVo> newItemPost(){
		List<ItemVo> list = itemService.newItemList();
		System.out.println(list);
		return list;
	}
	
	/* 아이템 create (GET) */
	@GetMapping(value = "/itemCreate")
	public ModelAndView itemCreateGet(@RequestParam String albumId) {
		ModelAndView ma = new ModelAndView();
		ma.addObject("albumId", albumId);
		ma.setViewName("album/itemCreate");
		return ma;
	
	}
	/* 아이템 create (POST) */
	@RequestMapping(value = "/itemCreate")
	public ModelAndView itemCreatePost(@RequestParam Map<String, Object> map,HttpSession session) {
		String loginId = (String) session.getAttribute("id");
		map.put("loginId", loginId);
		ModelAndView ma = new ModelAndView();
		int itemId = itemService.itemCreate(map);		
		
		ma.setViewName("redirect:/newAlbumList");
		
		return ma;
	}
	
	/* 아이템 detail */
	@RequestMapping(value = "/itemDetail", method = RequestMethod.GET)
	public ModelAndView itemDetail(
			@RequestParam("itemID") int itemID, 
			@RequestParam Map<String, Object> map) {
		itemService.viewCount(itemID);
		
		Map<String, Object> detailMap = itemService.detail(map);
		ModelAndView ma = new ModelAndView();
		ma.addObject("data", detailMap);
		ma.setViewName("/album/itemDetail");
		return ma;
	}
	
	
	/* 장르 리스트 */
	@GetMapping(value = "/genre")
	public ModelAndView newGenre(@RequestParam Map<String, Object> map){
		ModelAndView ma = new ModelAndView();
		
		List<ItemVo> list = itemService.newgenreList(map);

		ma.addObject("lists", list);
		ma.setViewName("/album/genreList");
		
//		int total = itemService.countItemList(cri);
//		PagingVo page = new PagingVo(cri, total);
//		
//		ma.addObject("pageMaker", page);
//		System.out.println(list);
		return ma;
	}

	
	/* 실시간 음악 - 곡(GET) */
	@GetMapping(value = "/bestItemList")
	public ModelAndView bestItemListGet() {
		ModelAndView ma = new ModelAndView("/album/bestItemList");
		return ma;
	}
	
	/* 실시간 음악 - 곡(POST) */
	@ResponseBody
	@PostMapping(value = "/bestItemList")
	public List<ItemVo> bestItemListPost() {
		List<ItemVo> list = itemService.bestItemList();
		
		return list;
	}
	
	
	/* 인기음악(GET) */
	@GetMapping(value = "/randomList")
	public ModelAndView randomListGet() {
		return new ModelAndView("/album/randomList");
	}
	
	/* 인기음악(POST) */
	@ResponseBody
	@PostMapping(value = "/randomList")
	public List<ItemVo> randomListPost() {
		List<ItemVo> list = itemService.randomList();
		return list;
	}
	
	

}
