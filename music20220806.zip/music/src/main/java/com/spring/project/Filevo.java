package com.spring.project;

import javax.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

public class Filevo {
	
	@NotNull
	private MultipartFile file;
	@NotNull
	String content;
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}	

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
}
