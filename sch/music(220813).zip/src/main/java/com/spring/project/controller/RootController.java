package com.spring.project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RootController {
	@GetMapping("/")
	public ModelAndView mainpage() {
		return new ModelAndView("test/test");
	}
	
	@PostMapping("/")
	public ModelAndView mainpagePost(@RequestParam String id, HttpSession session) 
	{
		session.setAttribute("id", "admin");  // 세션 셋팅
		System.out.println(id);
		return new ModelAndView("test/test");
	}
}
