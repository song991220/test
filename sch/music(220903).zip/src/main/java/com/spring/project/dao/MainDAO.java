package com.spring.project.dao;

import java.util.List;

import com.spring.project.vo.MainVO;

public interface MainDAO {
	
	public List<MainVO> itemlist() throws Exception;
	
	//public List<MainVO> lprodlist() throws Exception;
	
	// 게시물 목록
	public List<MainVO> list() throws Exception;

	// 게시물 작성
	public void write(MainVO vo) throws Exception;

	//게시물 조회
	public MainVO view(int id) throws Exception;
	
	// 게시물 수정
	public void modify(MainVO vo) throws Exception;

	// 게시물 삭제
	public void delete(int id) throws Exception;

	// 게시물 총 갯수 + 페이징
	public int count() throws Exception;

	// 게시물 목록 + 페이징 (게시물을 10개씩 출력하는 쿼리)
	public List<MainVO> listPage(int displayPost, int postNum) throws Exception;
	
	// 게시물 목록 + 페이징 + 검색
	 public List<MainVO> listPageSearch(
	   int displayPost, int postNum, String searchType, String keyword) throws Exception;
	
	// 게시물 총 갯수 + 검색 적용
	 public int searchCount(String searchType, String keyword) throws Exception;

}