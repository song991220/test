package com.spring.project.controller;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.io.DataOutputAsStream;
import com.spring.project.vo.BoardVO;
import com.spring.project.vo.Page;

@Controller

public class MainController {
	
	@RequestMapping(value = "main/main",method = RequestMethod.GET)
	public String main() {		
		return "main/main";
	}
	
	@RequestMapping(value = "main/test",method = RequestMethod.GET)
	public String test() {		
		return "main/test";
	}
	
	
}
	
