package com.spring.project.mapper;

import com.spring.project.vo.MusicMemberVo;


public interface MemberMapper {

	public MusicMemberVo loginCheck(MusicMemberVo vo);
	 
	

}
