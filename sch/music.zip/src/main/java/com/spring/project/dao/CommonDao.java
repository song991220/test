package com.spring.project.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.ComcodeVo;

@Repository
public class CommonDao {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	public void insertComcode(Map<String, Object> map) {

		sqlSessionTemplate.insert("insertComcode", map);
	}

	public List<ComcodeVo> selectCommonList() {

		return sqlSessionTemplate.selectList("selectCommonCode");
	}

}
