package com.spring.project.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.mapper.MemberMapper;
import com.spring.project.service.MusicMemberService;
import com.spring.project.vo.MusicMemberVo;

@Service
public class MusicMemberServiceImpl implements MusicMemberService {
	
	@Autowired
	MemberMapper membermapper;
	
	@Override
	public  MusicMemberVo loginCheck(MusicMemberVo vo) {
		
		 return membermapper.loginCheck(vo);
	}
}
