package com.spring.project.service;

import org.springframework.stereotype.Service;

import com.spring.project.vo.MusicMemberVo;

@Service
public interface MusicMemberService {
	
	public  MusicMemberVo loginCheck(MusicMemberVo vo);

}
