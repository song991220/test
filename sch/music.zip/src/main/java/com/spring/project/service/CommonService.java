package com.spring.project.service;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

import com.spring.project.vo.ComcodeVo;


public interface CommonService {

	void insertcomcode(Map<String, Object> map);

	List<ComcodeVo> selectCommonList();

	
}
