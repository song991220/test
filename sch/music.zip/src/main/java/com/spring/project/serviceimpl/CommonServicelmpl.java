package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.CommonDao;
import com.spring.project.service.CommonService;
import com.spring.project.vo.ComcodeVo;
@Service
public class CommonServicelmpl implements CommonService{
   
	@Autowired 
	CommonDao commonDao;
	
	@Override
	public void insertcomcode(Map<String, Object> map) {
		commonDao.insertComcode(map);
		
	}

    @Override
    public List<ComcodeVo> selectCommonList() {
    	return commonDao.selectCommonList();
    }

}
