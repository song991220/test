package com.spring.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.project.dao.MusicMemberDao;
import com.spring.project.vo.MusicMemberVo;

@Controller
public class MusicMemberController {
    @Autowired
    MusicMemberDao musicMemberDao;

   /* @RequestMapping(value="login")
    public String login(MusicMemberVo vo){
        try{
            vo= MusicMemberVo.login();//?
            if(vo.getId()!=null){
                return "loginOK";
            }else{
                return "loginFail";
            }
        }catch(Exception e){
            return "loginFail";
        }
    }*/
}