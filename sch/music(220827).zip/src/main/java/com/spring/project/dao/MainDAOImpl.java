package com.spring.project.dao;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.MainVO;


@Repository
public class MainDAOImpl implements MainDAO {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	private static String namespace = "board";

	// 게시물 목록
	@Override
	public List<MainVO> list() throws Exception {

		return sqlSessionTemplate.selectList(namespace + ".list");		
	}

	// 게시물 작성
	@Override
	public void write(MainVO vo) throws Exception {
		sqlSessionTemplate.insert(namespace + ".write", vo);
	}

//게시물 조회
	@Override
	public MainVO view(int id) throws Exception {
		// TODO Auto-generated method stub
		return sqlSessionTemplate.selectOne(namespace + ".view", id);		
	}

//게시물 수정
	@Override
	public void modify(MainVO vo) throws Exception {
		sqlSessionTemplate.update(namespace + ".modify", vo);
	}

//게시물 삭제
	public void delete(int id) throws Exception {
		sqlSessionTemplate.delete(namespace + ".delete", id);		
	}

	@Override
	public int count() throws Exception {
		return sqlSessionTemplate.selectOne(namespace + ".count");		
	}

	@Override // 게시물을 10개씩 출력하는 쿼리
	public List<MainVO> listPage(int displayPost, int postNum) throws Exception {
		HashMap data = new HashMap();

		data.put("displayPost", displayPost);
		data.put("postNum", postNum);

		return sqlSessionTemplate.selectList(namespace + ".listPage", data);
	}

//게시물 목록 + 페이징 + 검색
//메서드의 매개변수 -> searchType과 keyword을 받도록	
	@Override
	public List<MainVO> listPageSearch(int displayPost, int postNum, String searchType, String keyword)
			throws Exception {

		HashMap<String, Object> data = new HashMap<String, Object>();

		data.put("displayPost", displayPost);
		data.put("postNum", postNum);

		data.put("searchType", searchType);
		data.put("keyword", keyword);

		return sqlSessionTemplate.selectList(namespace + ".listPageSearch", data);
	}
	
	// 게시물 총 갯수 + 검색 적용
	@Override
	public int searchCount(String searchType, String keyword) throws Exception {
	 
	 HashMap<String, Object> data = new HashMap<String, Object>();
	 
	 data.put("searchType", searchType);
	 data.put("keyword", keyword);
	 
	 return sqlSessionTemplate.selectOne(namespace + ".searchCount", data); 
	}
}

