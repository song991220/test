package com.spring.project.service;

import java.util.List;
import java.util.Map;

import com.spring.project.vo.CriteriaVO;
import com.spring.project.vo.ItemVo;

public interface ItemService {

	List<ItemVo> newItemList();
	
	int countItemList(CriteriaVO cri);

	// 장르 리스트
	List<ItemVo> newgenreList(Map<String, Object> map);

}
