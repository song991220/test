package com.spring.project.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.project.vo.ComcodeVo;
import com.spring.project.vo.MemberVO;

@Repository
public class MemberDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	private static String namespace = "member";

	public void signUp(Map<String, Object> map) {
		sqlSessionTemplate.insert("signUp", map);

	}

	public String regdateCheck(MemberVO memberVO) {
		return sqlSessionTemplate.selectOne("memberRegdateCheck", memberVO);
	}

	public void modify(MemberVO memberVO) {

		sqlSessionTemplate.update(namespace + ".modify", memberVO);
	}

	public MemberVO memberInfo(String id) {
		return sqlSessionTemplate.selectOne(namespace + ".memberinfo", id);
	}
	
	public String idCheck(String id) {
		return sqlSessionTemplate.selectOne(namespace + ".idCheck", id);
	}
}
