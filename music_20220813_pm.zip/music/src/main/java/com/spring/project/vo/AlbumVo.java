package com.spring.project.vo;

public class AlbumVo {
	
	private String id, title,singersong,reg_user,up_user;
	private String img;
	private String reg_date,up_date;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSingersong() {
		return singersong;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public void setSingersong(String singersong) {
		this.singersong = singersong;
	}
	
	public String getReg_user() {
		return reg_user;
	}
	public void setReg_user(String reg_user) {
		this.reg_user = reg_user;
	}
	public String getUp_user() {
		return up_user;
	}
	public void setUp_user(String up_user) {
		this.up_user = up_user;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getUp_date() {
		return up_date;
	}
	public void setUp_date(String up_date) {
		this.up_date = up_date;
	}
	

	@Override
	public String toString() {
		return "AlbumVo [id=" + id + ", title=" + title + ", singersong=" + singersong + ", reg_user=" + reg_user
				+ ", up_user=" + up_user + ", img=" + img + ", reg_date=" + reg_date + ", up_date=" + up_date + "]";
	}
	
}
