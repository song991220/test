package com.spring.project.serviceimpl;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.project.dao.MemberDao;
import com.spring.project.security.Auth;
import com.spring.project.service.MemberService;
import com.spring.project.util.CommonAuth;
import com.spring.project.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao memberDao;


	// 로그인
		@Override
		public MemberVO memberInfo(String id, HttpSession session, MemberVO memberVO) {
			System.out.println("memberserviceimpl memberinfo : " + memberDao.memberInfo(id));
			
			return memberDao.memberInfo(id);
		}

	// 로그아웃
	@Override
	public void logout(HttpSession session) {
		session.invalidate(); // 세션 초기화
	}

	// 회원가입
	@Override
	public void signUp(Map<String, Object> map) {
		memberDao.signUp(map);
	}

	@Override
	public String regdateCheck(MemberVO memberVO) {
		String reg_date = memberDao.regdateCheck(memberVO);
		memberVO.setReg_date(reg_date);
		System.out.println("memberserviceimpl : " + memberVO.getReg_date());
		return reg_date;
	}

	@Override
	public void memberModify(MemberVO memberVO) {
		memberDao.modify(memberVO);
	}

	@Override
	public String idCheck(String id) {
		String cnt = memberDao.idCheck(id);
		System.out.println("cnt : "+cnt);
		return cnt;
	}
	
	
}
