package com.spring.project.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysql.cj.log.Log;
import com.spring.project.vo.ComcodeVo;

@Repository
public class CommonDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	// sql 경로를 설정
	private static String namespace = "common";

	public void insertComcode(Map<String, Object> map) {
		System.out.println(map);
//		System.out.println(sqlSessionTemplate.insert("insertComcode", map));
		sqlSessionTemplate.insert("insertComcode", map);
	}

	public List<ComcodeVo> selectCommonList() {
		// sqlSessionTemplate -> mybatis 를 이용하여 "selectComcode"라는 이름을 매칭해주는 것
		return sqlSessionTemplate.selectList("selectComcode");
	}

	public Map<String, Object> detail(ComcodeVo comcodeVo) {
		return sqlSessionTemplate.selectOne(namespace + ".detail", comcodeVo);
	}

	public List<ComcodeVo> detail2(ComcodeVo comcodeVo) {
//		System.out.println(groupcd +" : "+ code);
//		System.out.println("detail : "+sqlSessionTemplate.selectOne(namespace +".detail", comcodeVo));
//		System.out.println(comcodeVo.getGroupcd()+" : "+comcodeVo.getCode());
		return sqlSessionTemplate.selectList(namespace + ".detail2", comcodeVo);
//		return null;
	}

	public void update(ComcodeVo comcodeVo) {
		System.out.println("확인값 : " + namespace + ".update" + ", vo : " + comcodeVo);

		sqlSessionTemplate.update(namespace + ".update", comcodeVo);
	}

	public void delete(ComcodeVo comcodeVo) {
		System.out.println("comcodeVo : " + comcodeVo);
		Object obj = sqlSessionTemplate.update(namespace + ".delete", comcodeVo);
		System.out.println("obj : " + obj);
		sqlSessionTemplate.update(namespace + ".delete", comcodeVo);

	}

}
