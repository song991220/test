package com.spring.project.serviceimpl;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.AdminDao;
import com.spring.project.dao.CommonDao;
import com.spring.project.service.AdminService;
import com.spring.project.service.CommonService;
import com.spring.project.vo.AlbumVo;
import com.spring.project.vo.ComcodeVo;
import com.spring.project.vo.MemberVO;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminDao adminDao;

	@Override
	public List<MemberVO> adminDetail(MemberVO memberVO) {
		return adminDao.detail(memberVO);
	}


	@Override
	public void adminUpdate(MemberVO memberVO) {
		adminDao.update(memberVO);
	}

	@Override
	public List<AlbumVo> managerProduct(AlbumVo albumVo) {
		return adminDao.managerProduct(albumVo);
		// TODO Auto-generated method stub
	}
	
	@Override
	public void managerProductUpdate(AlbumVo albumVo) {
		adminDao.managerProductUpdate(albumVo);
	}
	
//	manager 상품관리 페이지 추가
	@Override
	public void managerProductInsert(Map<String, Object> map) {
		// TODO Auto-generated method stub
		adminDao.managerProductInsert(map);
	}


}
